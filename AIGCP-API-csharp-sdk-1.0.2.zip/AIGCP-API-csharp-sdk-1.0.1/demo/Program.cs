using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Specialized;
using System.Web;
using Signature;

namespace MainNamespace
{
    class Program
    {
        static async Task Main()
        {
            string key = "**";
            string secret = "**";
            Signature.Signer signer = new Signature.Signer(key, secret);

            string url = "http://openapi.meitu.com/demo/authorization";
            Console.WriteLine(url);

            HttpMethod method = HttpMethod.Post;
            //HttpMethod method = HttpMethod.Get;
            var headers = new Dictionary<string, string>
            {
                { Signature.Signer.HeaderContentType, "application/json" },
                { Signature.Signer.HeaderContentSha256, "UNSIGNED-PAYLOAD" },
                { Signature.Signer.HeaderHost, "openapi.meitu.com" }
            };
            string body = "iadsfasdf"; // Update with your request body

            var request = signer.Sign(url, method, headers, body);

            // Use the signed request to make the actual HTTP request
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response;
                try
                {
                    response = await client.SendAsync(request);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Failed to send request: " + ex.Message);
                    return;
                }

                using (var responseBody = await response.Content.ReadAsStreamAsync())
                using (var reader = new System.IO.StreamReader(responseBody))
                {
                    string result = await reader.ReadToEndAsync();
                    Console.WriteLine(result);
                }
            }
        }
    }
}
