using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using System.Web;

namespace Signature
{
    public class Signer
    {
        public const string BasicDateFormat = "yyyyMMddTHHmmssZ";
        public const string Algorithm = "SDK-HMAC-SHA256";
        public const string HeaderXDate = "X-Sdk-Date";
        public const string HeaderHost = "Host";
        public const string HeaderContentType = "Content-Type";
        public const string HeaderAuthorization = "Authorization";
        public const string HeaderContentSha256 = "X-Sdk-Content-Sha256";

        private readonly string Key;
        private readonly string Secret;

        public Signer(string key, string secret)
        {
            Key = key;
            Secret = secret;
        }

        public HttpRequestMessage Sign(string url, HttpMethod method, Dictionary<string, string> headers, string body)
        {
            DateTime t = DateTime.UtcNow;
            headers[HeaderXDate] = t.ToString(BasicDateFormat);

            var signedHeaders = SignedHeaders(headers);
            var canonicalRequest = CanonicalRequest(method.Method, url, headers, body, signedHeaders);

            var stringToSign = StringToSign(canonicalRequest, t.ToString(BasicDateFormat));

            var signature = SignStringToSign(stringToSign, Encoding.UTF8.GetBytes(Secret));

            var authValue = AuthHeaderValue(signature, Key, signedHeaders);
            headers[HeaderAuthorization] = authValue;

            var request = new HttpRequestMessage(method, url)
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json")
            };

            foreach (var header in headers)
            {
                if (string.Equals(header.Key, "Content-Type", StringComparison.OrdinalIgnoreCase))
                {
                    request.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
                }
                else
                {
                    request.Headers.Add(header.Key, header.Value);
                }
            }

            return request;
        }

        private string SignStringToSign(string stringToSign, byte[] signingKey)
        {
            using (var hmac = new HMACSHA256(signingKey))
            {
                var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(stringToSign));
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }

        private string AuthHeaderValue(string signature, string accessKey, List<string> signedHeaders)
        {
            string signedHeadersStr = string.Join(";", signedHeaders);
            string headerValue = $"{Algorithm} Access={accessKey}, SignedHeaders={signedHeadersStr}, Signature={signature}";
            string encodedVal = Convert.ToBase64String(Encoding.UTF8.GetBytes(headerValue));
            return $"Bearer {encodedVal}";
        }
        private string CanonicalRequest(string method, string url, Dictionary<string, string> headers, string body, List<string> signedHeaders)
        {
            var parsedURL = new Uri(url);
            var canonicalURI = parsedURL.AbsolutePath.EndsWith("/") ? parsedURL.AbsolutePath : parsedURL.AbsolutePath + "/";
            
            // 解析查询字符串，然后对参数进行排序和编码
            var parsedQuery = HttpUtility.ParseQueryString(parsedURL.Query);
            var canonicalQueryString = string.Join("&", parsedQuery.AllKeys.OrderBy(k => k).Select(k => $"{HttpUtility.UrlEncode(k)}={HttpUtility.UrlEncode(parsedQuery[k])}"));

            var canonicalHeaders = CanonicalHeaders(headers, signedHeaders);
            var signedHeadersStr = string.Join(";", signedHeaders);

            var hexencode = headers.ContainsKey(HeaderContentSha256) && !string.IsNullOrEmpty(headers[HeaderContentSha256]) 
                ? headers[HeaderContentSha256] 
                : HashSHA256(body);

            return $"{method}\n{canonicalURI}\n{canonicalQueryString}\n{canonicalHeaders}\n{signedHeadersStr}\n{hexencode}";
        }

        private string CanonicalHeaders(Dictionary<string, string> headers, List<string> signedHeaders)
        {
            var lowHeaders = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var keyValuePair in headers)
            {
                lowHeaders[keyValuePair.Key.ToLower()] = keyValuePair.Value.Trim();
            }

            var a = new List<string>();
            foreach (var key in signedHeaders)
            {
                var value = lowHeaders.ContainsKey(key.ToLower()) ? lowHeaders[key.ToLower()] : "";
                if (string.Equals(key, HeaderHost, StringComparison.OrdinalIgnoreCase))
                {
                    value = headers.ContainsKey(HeaderHost) ? headers[HeaderHost] : "";
                }
                a.Add($"{key}:{value}");
            }

            // 使用 Ordinal 比较器来排序
            a.Sort(StringComparer.Ordinal);
            return string.Join("\n", a);
        }

        private List<string> SignedHeaders(Dictionary<string, string> headers)
        {
            // 将所有的键转换为小写
            var signedHeaders = headers.Keys.Select(key => key.ToLower()).ToList();

            // 使用 Ordinal 比较器来排序
            signedHeaders.Sort(StringComparer.Ordinal);

            return signedHeaders;
        }

        private string StringToSign(string canonicalRequest, string timeFormat)
        {
            var hash = HashSHA256(canonicalRequest);
            return $"{Algorithm}\n{timeFormat}\n{hash}";
        }

        private string HashSHA256(string data)
        {
            using (var sha256 = SHA256.Create())
            {
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(data));
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }
    }
}
